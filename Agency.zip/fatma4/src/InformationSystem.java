import java.util.*;
public class InformationSystem extends Queue<Strategy> {
	private Database DB;
	String DBName = new String("Strategies");
	public InformationSystem() {
		DB =new Database();
		DB.addTable(DBName);
	}
	public synchronized void insert(Strategy s) {
		super.insert(s);// using queues insert
		if(s.getSerialNum()!=0)// if task is not illegal task is added to database
			DB.insert(DBName, s.getSerialNum(), s.getCodeName(), s.getCustomerType(), s.getLevel(), s.getEstimatedOpTime());
		this.notifyAll();
	}
	public synchronized Strategy extract() {
		while(buffer.isEmpty())  {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		Collections.min(this.buffer);// sorting the information system by ascending order before each extraction
		Strategy item = buffer.remove(0);
		return item;
	}

}
