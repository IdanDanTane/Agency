
public class Strategy implements Comparable<Strategy>{
	private int SerialNum;
	private String CodeName = new String();
	private int level;
	private int CustomerType;
	private int EstimatedOpTime;
	public Strategy(int Tasknum,String Name,int level,int CustomerType,int Time) {
		SerialNum  = Tasknum;
		CodeName = Name;
		this.level=level;
		this.CustomerType = CustomerType;
		EstimatedOpTime = Time;
	}
	public String toString() {
		return CodeName;
	}

	public int compareTo(Strategy s) {// defines natural compare between strategies, used for sorting the information system
		if(s.EstimatedOpTime<this.EstimatedOpTime)
			return 1;
		else if(s.EstimatedOpTime>this.EstimatedOpTime)
			return -1;
		else
			return 0;
	}
	/*
	 * getters below, no setters because strategy cant be changed after creation
	 */
	public int getCustomerType() {
		return CustomerType;
	}
	public int getLevel() {
		return level;
	}
	public int getSerialNum() {
		return SerialNum;
	}
	public int getEstimatedOpTime() {
		return EstimatedOpTime;
	}
	public String getCodeName() {
		return this.CodeName;
	}
}
