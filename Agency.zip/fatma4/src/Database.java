import java.sql.*;
public class Database {
	private Connection conn;
	private Statement stmt;
	ResultSet result=null;
	public Database(){
		try{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/test";
			conn=DriverManager.getConnection(url, "root", "root");
			stmt=conn.createStatement();
		}
		catch(ClassNotFoundException ex){
			ex.printStackTrace();
		}
		catch(SQLException ex){
			ex.printStackTrace();
		}
	}
	void addTable(String table) {
		try{
			stmt.executeUpdate("DROP TABLE " + table);
			stmt.executeUpdate("CREATE TABLE "+table+" (ID int, Code varchar(50),Client int,Severity int,Time int)");
		}
		catch(SQLException ex){
			ex.printStackTrace();
		}
	}
	void insert(String table, int ID, String Code,int Client,int Severity,int Time ) {
		try{
			stmt.executeUpdate("INSERT INTO "+table+" VALUES("+ID+", '"+Code+"',"+Client+","+Severity+","+Time+")");
		}
		catch(SQLException ex){
			ex.printStackTrace();
		}
	}
	void deleteRecord( String tableN, int ID ){
		try{
			stmt.executeUpdate("DELETE FROM "+tableN+" WHERE ID="+ID);
		}
		catch(SQLException ex){
			ex.printStackTrace();
		}
	}
	void dropTable(String tableN){
		try{
			stmt.executeUpdate("Drop TABLE "+tableN);
		}
		catch(SQLException ex){
		}
	}
	public void queryTest(){
		if(conn==null) return;
		String query="select * from Strategies";
		try{
			result=stmt.executeQuery(query);
			print();

		}catch(SQLException ex){
			ex.printStackTrace();
		}
	}
	public void print(){
		try{
			System.out.println("#  "+"ID"+"\t"+" Code"+"\t"+"Client"+"\t"+"Severity"+"\t"+"Time"+"\t");
			System.out.println("-  --------"+"\t"+" ------"+"\t"+" ------"+"\t"+" ------"+"\t"+" ------"+"\t");
			while(result.next()){
				int ID=result.getInt("ID");
				String Code=result.getString("Code");
				int Client=result.getInt("Client");
				int Severity=result.getInt("Severity");
				int Time=result.getInt("Time");
				System.out.println(result.getRow()+ "  "+ID+"\t  "+Code+"\t"+Client+"\t"+Severity+"\t"+Time+"\t");
			}
		}catch(SQLException ex) {
			ex.printStackTrace();}
	}
}


