
public class Executive extends AgencyWorker{
	private Agency workplace;
	private Operation CurrentOperation;
	private boolean EndDay = false;
	private AgencyManager MyManager ;
	private BoundedQueue<Operation> v ;// operation queue from agency
	public Executive(String name, Agency a, AgencyManager manager) {
		super(name);
		this.workplace = a ;
		v = a.getOperationQ();
		MyManager = manager;
	}
	public void run() {
		while(!EndDay) {
			CurrentOperation = v.extract();
			if (CurrentOperation==null) {
				try {
					this.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			else if(CurrentOperation.getLevel()!=-1){	
				try {
					Thread.sleep(OperationTime(CurrentOperation));// simulates operation time
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				while(CurrentOperation.GetVehiclesVec().size()>0) {
				workplace.ReturnVehicle(DismissVehicle());
				}
				while(CurrentOperation.GetInvestigatorsVec().size()>0) {
					workplace.ReturnInvestigator(DismissInvestigator());
					}
				while(CurrentOperation.GetDetectivesVec().size()>0) {
					workplace.ReturnDetective(DismissDetective());
					}
				CurrentOperation.GetAgentsVec().removeAllElements();
				this.MyManager.UpdateOpsDone();
				this.MyManager.UpdateDailyTime(OperationTime(CurrentOperation));
			}else {
				EndDay = true;
				v.insert(CurrentOperation);
			}

		}


	}
	private long OperationTime(Operation o) {// calculates operation time
		double Time = 0;
		Time = (o.GetAgentsVec().size()+o.GetVehiclesVec().size()+(Math.random()*(8-2)+2))*1000;
		return (long)Time;
	}
	/*
	 * returns agency resources from the operation to the agency
	 */
	private Vehicle DismissVehicle(){
		Vehicle v;
		v=CurrentOperation.GetVehiclesVec().remove(0);
		return v;
	}
	private Investigator DismissInvestigator(){
		Investigator i;
		i=CurrentOperation.GetInvestigatorsVec().remove(0);
		return i;
	}
	private Detective DismissDetective(){
		Detective d;
		d=CurrentOperation.GetDetectivesVec().remove(0);
		return d;
	}
}
