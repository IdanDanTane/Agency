
public class Secretary extends AgencyWorker{
	private Agency workplace;
	private Queue<Call> v ;// call queue from agency
	private Call currentCall;// pointer to current call that secretary holding
	public Secretary(String name, Agency a) {
		super(name);
		this.workplace = a ;
		v = a.getCallsQ();
	}

	
	public  void run() {
		while(workplace.getCallsTaken()<workplace.getAllDayCalls()) {
			currentCall = v.extract();
			if(!(currentCall==null)) {
				try {
					Thread.sleep((long)(currentCall.getDuration()+customerTypeDuration()));// simulates work time on a call
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				workplace.getTaskQ().insert(CallToTask());
				currentCall.FinishCall();//update the call that she is finished
				workplace.setCallsTaken(workplace.getCallsTaken() + 1); // updates the number of calls taken
				
			}
		}
		CheckEndDay();
	}
	private synchronized void CheckEndDay() {
		if(workplace.getCallsTaken() == workplace.getAllDayCalls())
			v.insert(null);
	}
	private synchronized Task CallToTask() {// create task from a call
		Task t = new Task(currentCall.getNameOfInterrogee(),currentCall.getOparationType(),currentCall.getCostumerType(),currentCall.getTimeOfArrival(),workplace.getNumberOfTasks());
		workplace.setNumberOfTasks(workplace.getNumberOfTasks() + 1);
		return t;
	}
	private int customerTypeDuration() {// calculates the added duration per customer type
		int addedDuration = 0;
		if(currentCall.getCostumerType() == 1 ) {
		 addedDuration=(int) ((Math.random()*(1000-500) + 500));
		}else if(currentCall.getCostumerType() == 2 ) {
			 addedDuration=(int) ((Math.random()*(2000-1000) + 1000));
		}else {
			 addedDuration=(int) ((Math.random()*(3000-2000) + 2000));
		}
		return addedDuration;
	}

}
