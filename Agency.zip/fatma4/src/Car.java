
public class Car extends Vehicle {
	public Car() {
		NumOfSeats = 5;
	}
}
