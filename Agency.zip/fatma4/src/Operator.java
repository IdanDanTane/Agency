import java.util.*;
public class Operator extends AgencyWorker {
	private Agency workplace;
	private InformationSystem i ;// information System from agency
	protected static int CallsTaken = 0;
	private Strategy CurrentStrategy;
	private Vector<Agent> AgentsVec;
	private Vector<Detective> DetectivesVec;
	private Vector<Investigator> InvestigatorsVec;
	private Vector<Vehicle> VehiclesVec;
	private boolean EndDay = false;
	private long WorkTime;
	public Operator(String name, Agency a, long worktime) {
		super(name);
		this.workplace = a ;
		i = a.getInfo_sys();
		this.WorkTime=worktime;
	}
	public synchronized void  run() {
		while(!EndDay) {
			CurrentStrategy = i.extract();
			if (CurrentStrategy==null) {
					try {
					this.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}if(EndDay) {
					break;
				}
			}
			else if(CurrentStrategy.getEstimatedOpTime()!=0){// while estimated time is legal
				workplace.getOperationQ().insert(StrategyToOperation(CurrentStrategy));
				try {
					Thread.sleep(WorkTime);// simulates work time
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}else {
				EndDay = true;
				i.insert(CurrentStrategy);
				notifyAll();
				continue;
			}

		}notifyAll();


	}
	private Operation StrategyToOperation(Strategy s) {// crates operation from strategy
		Operation o = new Operation(s.getSerialNum(),s.getCodeName(),s.getLevel(),s.getCustomerType(),s.getEstimatedOpTime());
		AgentsVec = o.GetAgentsVec();
		VehiclesVec = o.GetVehiclesVec();
		DetectivesVec = o.GetDetectivesVec();
		InvestigatorsVec = o.GetInvestigatorsVec();
		if(o.getLevel()==1) {
			o.InvestigatorsRequierd = 2;
			LevelOneOp(o);
		}if(o.getLevel()==2) {
			o.InvestigatorsRequierd = 3;
			o.DetectivesRequierd = 2;
			LevelTwoOp(o);
		}if(o.getLevel()==3) {
			o.InvestigatorsRequierd = 1;
			o.DetectivesRequierd = 5;
			LevelThreeOp(o);
		}if(o.getLevel()==4) {
			o.InvestigatorsRequierd = 4;
			o.DetectivesRequierd = 6;
			LevelFourOp(o);
		}if(o.getLevel()==5) {
			o.InvestigatorsRequierd = 7;
			o.DetectivesRequierd = 8;
			LevelFiveOp(o);
		}
		return o;


	}
	private void LevelOneOp(Operation o) {//crates level 1 operation by its rules
		for(int i = 0; i<o.InvestigatorsRequierd;i++) {
			Investigator in = workplace.TakeInvestigator();
			AgentsVec.add(in);
			InvestigatorsVec.add(in);
		}
		VehiclesVec.add(workplace.TakeVehicle());
		while(o.TotalSeats()<o.SeatsRequired())
			VehiclesVec.add(workplace.TakeVehicle());
	}
	private void LevelTwoOp(Operation o) {//crates level 2 operation by its rules
		for(int i = 0; i<o.InvestigatorsRequierd;i++) {
			Investigator in = workplace.TakeInvestigator();
			AgentsVec.add(in);
			InvestigatorsVec.add(in);
		}
		for(int i = 0; i<o.DetectivesRequierd;i++) {
			Detective det = workplace.TakeDetective();
			AgentsVec.add(det);
			DetectivesVec.add(det);
		}
		VehiclesVec.add(workplace.TakeVehicle());
		while(o.TotalSeats()<o.SeatsRequired())
			VehiclesVec.add(workplace.TakeVehicle());
	}
	private void LevelThreeOp(Operation o) {//crates level 3 operation by its rules
		for(int i = 0; i<o.InvestigatorsRequierd;i++) {
			Investigator in = workplace.TakeInvestigator();
			AgentsVec.add(in);
			InvestigatorsVec.add(in);
		}
		for(int i = 0; i<o.DetectivesRequierd;i++) {
			Detective det = workplace.TakeDetective();
			AgentsVec.add(det);
			DetectivesVec.add(det);
		}
		VehiclesVec.add(workplace.TakeVehicle());
		while(o.TotalSeats()<o.SeatsRequired())
			VehiclesVec.add(workplace.TakeVehicle());
	}
	private void LevelFourOp(Operation o) {//crates level 4 operation by its rules
		for(int i = 0; i<o.InvestigatorsRequierd;i++) {
			Investigator in = workplace.TakeInvestigator();
			AgentsVec.add(in);
			InvestigatorsVec.add(in);
		}
		for(int i = 0; i<o.DetectivesRequierd;i++) {
			Detective det = workplace.TakeDetective();
			AgentsVec.add(det);
			DetectivesVec.add(det);
		}
		VehiclesVec.add(workplace.TakeVehicle());
		while(o.TotalSeats()<o.SeatsRequired())
			VehiclesVec.add(workplace.TakeVehicle());
	}
	private void LevelFiveOp(Operation o) {//crates level 5 operation by its rules
		for(int i = 0; i<o.InvestigatorsRequierd;i++) {
			Investigator in = workplace.TakeInvestigator();
			AgentsVec.add(in);
			InvestigatorsVec.add(in);
		}
		for(int i = 0; i<o.DetectivesRequierd;i++) {
			Detective det = workplace.TakeDetective();
			AgentsVec.add(det);
			DetectivesVec.add(det);
		}
		VehiclesVec.add(workplace.TakeVehicle());
		while(o.TotalSeats()<o.SeatsRequired())
			VehiclesVec.add(workplace.TakeVehicle());
	}
}