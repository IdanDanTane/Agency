
public class AgencyManager implements Runnable{
	private Agency workplace;
	private int OperatoinsHandled ;
	private int DailyOperatoins ;
	private long AllOperationsTime;
	public AgencyManager(Agency a,int dailyOps) {
		workplace = a;
		OperatoinsHandled = 0;
		DailyOperatoins = dailyOps ;
		AllOperationsTime=0; 
	}
	public synchronized void  UpdateDailyTime(long time) {// updating daily operation time counter
		AllOperationsTime += time;
		notifyAll();
	}
	public synchronized void  UpdateOpsDone() {// updates daily operation counter
		OperatoinsHandled ++;
		notifyAll();
	}
	public synchronized void run() {
		while(OperatoinsHandled<DailyOperatoins) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		}
		workplace.getInfo_sys().insert(new Strategy(0,null,0,0,0));// ending operators day by adding illegal strategy
		workplace.getOperationQ().insert(new Operation(-1, null, -1, -1, -1));// ending executives day by adding illegal operation
		workplace.getTaskQ().insert(new Task(null,null,-1,-1,0));// ending task managers day by adding illegal task
		System.out.println("Total Operations of the day : " + OperatoinsHandled);// prints end day message
		System.out.println("Total Time Consumed for operations : " + AllOperationsTime);// prints end day message

		
	}
	
}
