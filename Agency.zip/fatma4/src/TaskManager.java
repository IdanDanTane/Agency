
public class TaskManager extends AgencyWorker {
	private Agency workplace;
	private Queue<Task> v ;
	private boolean EndDay = false;
	private InformationSystem infosys;
	public TaskManager(String name, Agency a) {
		super(name);
		workplace = a;
		v = a.getTaskQ();
		infosys = a.getInfo_sys();
	}
	public Task currentTask;// pointer to current task that secretary holding
	public void run() {
		while(!EndDay) {
			currentTask = v.extract();
			if(currentTask.getCustomerType()!=-1) {
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				PutStrategyInIS(crateStrategy(currentTask));
				System.out.println("Task " + currentTask.getTaskNumber() + " converted and stored on the system");
				
			}else {
				EndDay= true;
				v.insert(currentTask);
			}
		}
	}

	private synchronized Strategy crateStrategy(Task t) {// creates strategy from task
		String CodeName = swap(t.getNameOfInterrogee());
		int level = levelDecider(t.getOperationType());
		int Time = (level*t.getCustomerType())*1000;
		return new Strategy(t.getTaskNumber(),CodeName,level,t.getCustomerType(),Time);
	}
	private synchronized void  PutStrategyInIS(Strategy s) {// puts the strategy in the information system
		infosys.insert(s);
	}

	private static String swap(String a) // crates anagram from the interrogee name
	{ 
		char temp;
		int i;
		char[] charArray = a.toCharArray(); 
		temp = charArray[0];
		for (i = 0; i<charArray.length-1;i++) {
			charArray[i] = charArray[i+1];
	}
		charArray[i] = temp; 
		return String.valueOf(charArray);
	}
	private static int levelDecider(String s) {// converts the operation level from string to number
		if(s.equals("inquiry")){
			return 1;
		}if(s.equals("Background check")){
			return 2;
		} if(s.equals("surveillance")){
			return 3;
		} if(s.equals("fraud and illegal activity")){
			return 4;
		} if(s.equals("missing people")){
			return 5;
		}
		return 0;
	}
}
