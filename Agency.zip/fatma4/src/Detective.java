
public class Detective extends Agent{

}
