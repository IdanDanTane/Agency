import java.util.*;

public class Operation {
	private int SerialNum;
	private String CodeName = new String();
	private int level;
	private int CustomerType;
	private int EstimatedOpTime;
	private Vector<Vehicle> OpVehicles = new Vector<Vehicle>();
	public int InvestigatorsRequierd = 0;
	public int DetectivesRequierd = 0;
	private Vector<Detective> OpDetectives = new Vector<Detective>();
	private Vector<Investigator> OpInvestigators= new Vector <Investigator>();
	private Vector<Agent> OpAgents = new Vector<Agent>();
	public Operation(int Serialnum,String Name,int level,int CustomerType,int Time) {
		SerialNum  = Serialnum;
		CodeName = Name;
		this.level=level;
		this.CustomerType = CustomerType;
		EstimatedOpTime = Time;
	}
	/*
	 * getters below, no setters because the operation cant be changed after creation
	 */
	public Vector<Agent> GetAgentsVec() {
		return OpAgents;
	}
	public Vector<Detective> GetDetectivesVec() {
		return OpDetectives;
	}
	public Vector<Investigator> GetInvestigatorsVec() {
		return OpInvestigators;
	}
	public Vector<Vehicle> GetVehiclesVec()  {
		return OpVehicles;
	}
	public int TotalSeats() {// calculates total seats available
		int TotalSeats = 0 ;
		for(int i =0; i<OpVehicles.size();i++)
			TotalSeats+=OpVehicles.get(i).NumOfSeats;
		 return TotalSeats;
	}
	public int SeatsRequired() {
		return InvestigatorsRequierd+DetectivesRequierd;
	}
	public int getSerialNum() {
		return SerialNum;
	}
	public String getCodeName() {
		return CodeName;
	}
	public int getLevel() {
		return level;
	}
	public int getCustomerType() {
		return CustomerType;
	}
	public int getEstimatedOpTime() {
		return EstimatedOpTime;
	}
}
