
public class Task {
	private int TaskNumber;
	private String NameOfInterrogee = new String();
	private String OperationType= new String();
	private int CustomerType ;
	private int TimeOfArrival;
	public Task(String NameOfInterrogee,String OperationType,int CustomerType,int TimeOfArrival,int taskNumber) {
		this.TaskNumber = taskNumber;
		this.NameOfInterrogee = NameOfInterrogee;
		this.OperationType = OperationType;
		this.CustomerType = CustomerType;
		this.TimeOfArrival = TimeOfArrival;
	}
	/*
	 * getters below, no setters because task cant be changed after creation
	 */
	public int getTaskNumber() {
		return TaskNumber;
	}
	public String getNameOfInterrogee() {
		return NameOfInterrogee;
	}
	public String getOperationType() {
		return OperationType;
	}
	public int getCustomerType() {
		return CustomerType;
	}
	public int getTimeOfArrival() {
		return TimeOfArrival;
	}
}
