
public class BoundedQueue<T> extends Queue<T>{
	private int Capacity;
	public BoundedQueue(int MaxCap) {
		super();
		this.Capacity=MaxCap;// capacity of the bounded queue that was given in constructor
	}
	public synchronized void insert(T item) {
		while(buffer.size()>=Capacity) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		super.insert(item);// insertion using the queues insert method
	}

	public synchronized T extract()  {
		T item = super.extract();
		notifyAll();
		return item;
	}

}
