import java.io.*;
import java.util.*;
public class Agency {
	private Queue<Call> CallsQ = new Queue<Call>();
	private Queue<Task> TaskQ = new Queue<Task>();
	private BoundedQueue<Operation> OperationQ = new BoundedQueue<Operation>(15);
	private int AllDayCalls = 0 ;
	private int callsTaken =0;
	private int numberOfTasks = 1;
	private InformationSystem info_sys = new InformationSystem();
	private Vector<Detective> AgencyDetectives = new Vector<Detective>();
	private Vector<Investigator> AgencyInvestigators = new Vector<Investigator>();
	private Vector<Vehicle> AgencyVehicles = new Vector<Vehicle>();
	public Agency(String Calls) {
		readCalls(Calls);
	}
	public void readCalls(String Calls) {// reading calls from file
		try {
			Scanner input = new Scanner(new File(Calls));
			input.useDelimiter("	|\n|\r");
			input.nextLine();
			while (input.hasNext()) {
				String Callname = input.next();
				String Service = input.next();
				String Customertype = input.next();
				int Arrival = input.nextInt();
				int Duration = input.nextInt();
				Call c = new Call(Callname, Service,Customertype,Arrival, Duration,CallsQ);
				AllDayCalls ++;
				Thread t = new Thread(c);
				t.start();
				input.nextLine();
			}
		} catch (IOException IOE) {
			IOE.printStackTrace();
		}
	}
	/*
	 * getters and setters below
	 */
	public synchronized Detective TakeDetective() {
		while(AgencyDetectives.size()==0) {
			try {
				this.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		return AgencyDetectives.remove(0);
	}
	public synchronized Investigator TakeInvestigator() {
		while(AgencyInvestigators.size()==0) {
			try {
				this.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		return AgencyInvestigators.remove(0);
	}
	public synchronized Vehicle TakeVehicle() {
		while(AgencyVehicles.size()==0) {
			try {
				this.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		return AgencyVehicles.remove(0);
	}
	public synchronized void ReturnVehicle(Vehicle v) {
		AgencyVehicles.add(v);
		notifyAll();
	}
	public synchronized void ReturnInvestigator(Investigator i) {
		AgencyInvestigators.add(i);
		notifyAll();
	}
	public synchronized void ReturnDetective(Detective d) {
		AgencyDetectives.add(d);
		notifyAll();
	}
	public void initialize() {// initializing the agency resources
		for(int i = 0; i<60;i++) {
			this.AgencyDetectives.add(new Detective());
			if(i<50)
				this.AgencyVehicles.add(new Motorcycle());
			if(i<40)
				this.AgencyInvestigators.add(new Investigator());
			if(i<10)
				this.AgencyVehicles.add(new Car());
			
	}
		
	}
	public int getNumberOfTasks() {
		return numberOfTasks;
	}
	public void setNumberOfTasks(int numberOfTasks) {
		this.numberOfTasks = numberOfTasks;
	}
	public InformationSystem getInfo_sys() {
		return info_sys;
	}
	public int getCallsTaken() {
		return callsTaken;
	}
	public void setCallsTaken(int callsTaken) {
		this.callsTaken = callsTaken;
	}
	public int getAllDayCalls() {
		return AllDayCalls;
	}
	public BoundedQueue<Operation> getOperationQ() {
		return OperationQ;
	}
	public Queue<Task> getTaskQ() {
		return TaskQ;
	}
	public Queue<Call> getCallsQ() {
		return CallsQ;
	}
	
}
