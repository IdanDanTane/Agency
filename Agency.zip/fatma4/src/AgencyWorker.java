
public abstract class AgencyWorker implements Runnable {
protected String Name;
public AgencyWorker(String newName) {
	this.Name = newName;
}
}
