
public class Investigator extends Agent{

}
