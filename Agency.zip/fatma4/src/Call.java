
public class Call implements Runnable{
	private String NameOfInterrogee = new String();
	private String OparationType= new String();
	private int CostumerType;
	private int TimeOfArrival;
	private int duration;
	private Queue<Call> callQ = new Queue<Call>();
	private boolean Finished = false;
	public Call(String Name,String Service,String Customer, int Arrival,int Duration,Queue<Call> callsQ) {
		NameOfInterrogee = Name;
		OparationType = Service;
		if(Customer.equals("private")){
			CostumerType=1;
		}if(Customer.equals("business")){
			CostumerType=2;
		}if(Customer.equals("government")){
			CostumerType=3 ;
		}
		TimeOfArrival = Arrival*1000;
		this.duration=Duration*1000;
		this.callQ=callsQ;
	}
	public void run() {
		this.SleepUntilArrival();
		callQ.insert(this);
		waitForFinish();
		}
	public void SleepUntilArrival(){
	try {
			Thread.sleep(TimeOfArrival);// sleep until arrival simulation
		} catch (InterruptedException e) {}
	}
	public synchronized void waitForFinish() {// wait until call converted to task
		while(!Finished) {
			try {
				this.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
	}
	}
	public synchronized void FinishCall(){// notify the call that she is finished
		this.Finished = true;
		notifyAll();
	}
	/*
	 * getters below, there are no setters because the call cannot be changed after its making
	 */
	public int getDuration() {
		return duration;
	}
	public int getCostumerType() {
		return CostumerType;
	}
	public String getOparationType() {
		return OparationType;
	}
	public String getNameOfInterrogee() {
		return NameOfInterrogee;
	}
	public int getTimeOfArrival() {
		return TimeOfArrival;
	}
}
