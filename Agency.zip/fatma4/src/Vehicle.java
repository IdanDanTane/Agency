
public abstract class Vehicle{
	protected int NumOfSeats ;
}
