import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JTextPane;
import javax.swing.JSpinner;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.SpinnerNumberModel;
import javax.swing.UIManager;
import com.jgoodies.forms.factories.DefaultComponentFactory;

public class GUI {

	private JFrame frame;
	private JTextField txtTheMaximumNumber;
	private JTextField txtTheMaximumNumber_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI window = new GUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(SystemColor.window);
		frame.setBounds(100, 100, 541, 511);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("Fatma Agency Call Center Starter");
		lblNewLabel.setBounds(0, 32, 517, 44);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("David", Font.BOLD, 14));
		lblNewLabel.setBackground(Color.GRAY);
		frame.getContentPane().add(lblNewLabel);



		JTextPane txtpnOpertors = new JTextPane();
		txtpnOpertors.setEditable(false);
		txtpnOpertors.setFont(new Font("Arial", Font.PLAIN, 14));
		txtpnOpertors.setText("Opertors working time :");
		txtpnOpertors.setBounds(62, 137, 243, 20);
		frame.getContentPane().add(txtpnOpertors);

		JTextPane txtpnNumberOfExecutives = new JTextPane();
		txtpnNumberOfExecutives.setEditable(false);
		txtpnNumberOfExecutives.setToolTipText("");
		txtpnNumberOfExecutives.setText("Number of Executives :");
		txtpnNumberOfExecutives.setFont(new Font("Arial", Font.PLAIN, 14));
		txtpnNumberOfExecutives.setBounds(62, 188, 243, 20);
		frame.getContentPane().add(txtpnNumberOfExecutives);

		JTextPane txtpnNumberOfOperations = new JTextPane();
		txtpnNumberOfOperations.setEditable(false);
		txtpnNumberOfOperations.setText("Number of operations of the day : ");
		txtpnNumberOfOperations.setFont(new Font("Arial", Font.PLAIN, 14));
		txtpnNumberOfOperations.setBounds(62, 241, 243, 20);
		frame.getContentPane().add(txtpnNumberOfOperations);

		JSpinner OperatorWorkTime = new JSpinner();
		OperatorWorkTime.setModel(new SpinnerNumberModel(new Double(1), null, null, new Double(0)));
		OperatorWorkTime.setFont(new Font("Arial", Font.PLAIN, 14));
		OperatorWorkTime.setBounds(383, 137, 61, 20);
		frame.getContentPane().add(OperatorWorkTime);

		JSpinner UserExecutiveNumber = new JSpinner();
		UserExecutiveNumber.setModel(new SpinnerNumberModel(new Integer(0), new Integer(0), null, new Integer(1)));
		UserExecutiveNumber.setFont(new Font("Arial", Font.PLAIN, 14));
		UserExecutiveNumber.setBounds(383, 188, 61, 20);
		frame.getContentPane().add(UserExecutiveNumber);

		JSpinner DailyOpNum = new JSpinner();
		DailyOpNum.setModel(new SpinnerNumberModel(new Integer(10), null, null, new Integer(1)));
		DailyOpNum.setFont(new Font("Arial", Font.PLAIN, 14));
		DailyOpNum.setBounds(383, 241, 61, 20);
		frame.getContentPane().add(DailyOpNum);

		JButton btnStart = new JButton("START");
		btnStart.setBackground(SystemColor.activeCaption);
		btnStart.setFont(new Font("Arial", Font.BOLD, 18));
		btnStart.setBounds(62, 380, 131, 23);
		frame.getContentPane().add(btnStart);
		btnStart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double OpTime = (double)OperatorWorkTime.getValue();
				int NumOfExecutives = (int)UserExecutiveNumber.getValue();
				int DailyOps = (int)DailyOpNum.getValue();
				if(NumOfExecutives>8) {
					NumOfExecutives=8;
					txtTheMaximumNumber = new JTextField();
					txtTheMaximumNumber.setForeground(UIManager.getColor("ToolBar.dockingForeground"));
					txtTheMaximumNumber.setBackground(UIManager.getColor("TextField.shadow"));
					txtTheMaximumNumber.setEditable(false);
					txtTheMaximumNumber.setHorizontalAlignment(SwingConstants.CENTER);
					txtTheMaximumNumber.setText("The number Executives in the agency has been set to 8.");
					txtTheMaximumNumber.setBounds(86, 327, 346, 30);
					frame.getContentPane().add(txtTheMaximumNumber);
					txtTheMaximumNumber.setColumns(10);

					txtTheMaximumNumber_1 = new JTextField();
					txtTheMaximumNumber_1.setText("The maximum number of Executives has been exceeded !");
					txtTheMaximumNumber_1.setHorizontalAlignment(SwingConstants.CENTER);
					txtTheMaximumNumber_1.setForeground(UIManager.getColor("ToolBar.dockingForeground"));
					txtTheMaximumNumber_1.setEditable(false);
					txtTheMaximumNumber_1.setColumns(10);
					txtTheMaximumNumber_1.setBackground(UIManager.getColor("TextField.shadow"));
					txtTheMaximumNumber_1.setBounds(86, 298, 346, 30);
					frame.getContentPane().add(txtTheMaximumNumber_1);
				}
				Agency AgencyCallCenter = new Agency("src/calls.txt");
				AgencyCallCenter.initialize();// starting the agency
				startCallCenter(AgencyCallCenter, (long)OpTime, NumOfExecutives,DailyOps);// starting all agency workers
			}
		});

		JButton btnExit = new JButton("EXIT");
		btnExit.setBackground(SystemColor.activeCaption);
		btnExit.setFont(new Font("Arial", Font.BOLD, 18));
		btnExit.setBounds(330, 382, 131, 23);
		frame.getContentPane().add(btnExit);
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);		
			}
		});
	}
/*\
 * starting the agency workers by using threads
 */
	public static void startCallCenter(Agency a, long workingTime, int ExecNum,int DailyOps) {
		AgencyManager A1 = new AgencyManager(a, DailyOps);
		Thread t = new Thread(A1);
		t.start();
		initSecretries(a);
		initTaskManagers(a);
		initOperators(a,workingTime);
		initExecutives(a, ExecNum, A1);


	}
	public static void initSecretries(Agency a) {
		for (int i = 0 ; i<5; i ++) {
			Secretary sec = new Secretary("sec", a);
			Thread t =new Thread(sec);
			t.start();
		}
	}
	public static void initTaskManagers(Agency a) {
		for (int i = 0 ; i<3; i ++) {
			TaskManager TaskM = new TaskManager("TaskM", a);
			Thread t =new Thread(TaskM);
			t.start();
		}
	}
	public static void initOperators(Agency a, long workingTime) {
		for (int i = 0 ; i<3; i ++) {
			Operator operator = new Operator("operOne",a,workingTime);
			Thread t =new Thread(operator);
			t.start();
		}
	}
	public static void initExecutives(Agency a, int ExecNum, AgencyManager MyManager) {
		for (int i = 0 ; i<5+ExecNum; i ++) {
			Executive exec = new Executive("exec",a,MyManager);
			Thread t =new Thread(exec);
			t.start();
		}

	}
}
