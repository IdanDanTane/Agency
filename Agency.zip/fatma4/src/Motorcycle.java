
public class Motorcycle extends Vehicle {
	public Motorcycle() {
		NumOfSeats = 1;
	}
}
